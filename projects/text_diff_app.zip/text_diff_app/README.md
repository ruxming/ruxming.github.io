# 文本比较工具

这是一个基于Python Flask的网站应用，用于上传和比较两个文本文档，以类似GitHub diff的方式显示差异。

## 功能特点

- 支持上传两个文本文件（.txt格式）进行比较
- 使用类似GitHub diff的方式显示差异（绿色表示添加，红色表示删除，黄色表示修改）
- 简洁直观的用户界面
- 响应式设计，适配不同设备

## 系统要求

- Windows 11/10/8/7
- Python 3.8或更高版本

## 安装和运行

1. 解压下载的zip文件到任意目录
2. 双击运行`install_dependencies.bat`安装依赖
3. 安装完成后，双击运行`start_server.bat`启动服务器
4. 服务器启动后，双击运行`test_app.bat`或在浏览器中访问`http://localhost:5000`使用应用

## 使用方法

1. 在应用界面上，点击"选择文件"按钮上传第一个文本文件
2. 点击第二个"选择文件"按钮上传第二个文本文件
3. 点击"比较文件"按钮进行比较
4. 比较结果将显示在页面下方，使用不同颜色标记差异：
   - 绿色：添加的内容
   - 红色：删除的内容
   - 黄色：修改的内容

## 项目结构

```
text_diff_app/
├── src/                  # 源代码目录
│   ├── routes/           # 路由文件
│   │   ├── diff.py       # 文本比较路由
│   │   └── user.py       # 用户API路由（示例）
│   ├── static/           # 静态文件
│   │   └── index.html    # 前端页面
│   └── main.py           # 应用入口点
├── venv/                 # 虚拟环境（安装后生成）
├── requirements.txt      # 依赖列表
├── install_dependencies.bat  # 安装依赖脚本
├── start_server.bat      # 启动服务器脚本
└── test_app.bat          # 测试应用脚本
```

## 在线演示

您可以访问以下链接查看在线演示：
https://4w5hni7cdmmd.manus.space

## 问题排查

如果遇到问题，请检查：

1. 确保Python已正确安装并添加到PATH
2. 确保端口5000未被其他应用占用
3. 如果依赖安装失败，请尝试手动运行以下命令：
   ```
   python -m pip install --upgrade pip
   python -m pip install -r requirements.txt
   ```

## 许可证

MIT

