from flask import Blueprint, jsonify, request, current_app
import os
import difflib
import tempfile

diff_bp = Blueprint('diff', __name__)

UPLOAD_FOLDER = os.path.join(tempfile.gettempdir(), 'text_diff_uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@diff_bp.route('/compare', methods=['POST'])
def compare_texts():
    """
    比较两个上传的文本文件并返回差异结果
    """
    if 'file1' not in request.files or 'file2' not in request.files:
        return jsonify({'error': '需要上传两个文件'}), 400
    
    file1 = request.files['file1']
    file2 = request.files['file2']
    
    if file1.filename == '' or file2.filename == '':
        return jsonify({'error': '文件名不能为空'}), 400
    
    if not (file1.filename.endswith('.txt') and file2.filename.endswith('.txt')):
        return jsonify({'error': '只支持.txt文件格式'}), 400
    
    try:
        # 读取文件内容
        text1 = file1.read().decode('utf-8').splitlines()
        file1.close()
        
        text2 = file2.read().decode('utf-8').splitlines()
        file2.close()
        
        # 使用difflib生成差异
        diff = difflib.HtmlDiff()
        diff_html = diff.make_file(text1, text2, file1.filename, file2.filename)
        
        # 返回HTML格式的差异结果
        return jsonify({
            'diff_html': diff_html,
            'file1_name': file1.filename,
            'file2_name': file2.filename
        })
    
    except Exception as e:
        return jsonify({'error': f'比较文件时出错: {str(e)}'}), 500

@diff_bp.route('/compare-raw', methods=['POST'])
def compare_raw_texts():
    """
    比较两个原始文本并返回差异结果
    """
    data = request.json
    if not data or 'text1' not in data or 'text2' not in data:
        return jsonify({'error': '需要提供两个文本'}), 400
    
    try:
        # 获取文本内容
        text1 = data['text1'].splitlines()
        text2 = data['text2'].splitlines()
        
        # 使用difflib生成差异
        diff = difflib.HtmlDiff()
        diff_html = diff.make_file(text1, text2, "文本1", "文本2")
        
        # 返回HTML格式的差异结果
        return jsonify({
            'diff_html': diff_html
        })
    
    except Exception as e:
        return jsonify({'error': f'比较文本时出错: {str(e)}'}), 500

