#!/usr/bin/env python
import requests
import os

# 测试文件路径
file1_path = '/home/ubuntu/text_diff_app/test_file1.txt'
file2_path = '/home/ubuntu/text_diff_app/test_file2.txt'

# API URL
api_url = 'https://4w5hni7cdmmd.manus.space/api/diff/compare'

# 准备文件
files = {
    'file1': ('test_file1.txt', open(file1_path, 'rb'), 'text/plain'),
    'file2': ('test_file2.txt', open(file2_path, 'rb'), 'text/plain')
}

# 发送请求
print("发送文件比较请求...")
response = requests.post(api_url, files=files)

# 检查响应
if response.status_code == 200:
    print("请求成功！")
    result = response.json()
    
    # 保存HTML结果到文件
    if 'diff_html' in result:
        with open('diff_result.html', 'w', encoding='utf-8') as f:
            f.write(result['diff_html'])
        print(f"比较结果已保存到 diff_result.html")
        
        # 打印文件名信息
        print(f"文件1: {result.get('file1_name', 'test_file1.txt')}")
        print(f"文件2: {result.get('file2_name', 'test_file2.txt')}")
    else:
        print("响应中没有找到diff_html字段")
        print("响应内容:", result)
else:
    print(f"请求失败，状态码: {response.status_code}")
    print("错误信息:", response.text)

# 关闭文件
for file_obj in files.values():
    file_obj[1].close()

print("测试完成！")

